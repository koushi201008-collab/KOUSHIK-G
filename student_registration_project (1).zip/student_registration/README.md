# Student Registration & Contact Intelligence System

**Course:** Semester 1 BCA – Python Programming  
**Project:** Section C – Student Registration & Contact Intelligence System

## 1. Project overview
This pure-Python command-line application reads student contacts from `contacts.csv`, validates names, phone numbers and email addresses, rejects invalid or duplicate records, stores accepted students in `students_clean.csv`, and provides student-management features and a business-intelligence report.

## 2. Requirements
- Python 3.8 or later
- No third-party packages are required. The project uses Python standard-library modules (`csv`, `pathlib`).

## 3. Project structure
```text
student_registration/
├── contacts.csv
├── students_clean.csv          # created automatically on first run
├── validator.py                # name, phone and email validation
├── loader.py                   # CSV ingestion, duplicate handling, file storage
├── analytics.py                # data-quality, prefix and email-domain reports
├── main.py                     # seven-option interactive console
├── proof/
│   ├── console_output.txt
│   └── test_cases.txt
└── README.md
```

## 4. Validation rules
1. **Name:** cannot be blank or whitespace only.
2. **Phone:** exactly 10 digits; digits only; first digit must be 6, 7, 8 or 9.
3. **Email:** exactly one `@`; no whitespace; at least one character before `@`; domain must contain a period which is not its first or last character.
4. **Duplicates:** a phone number or email address already accepted cannot be registered again.

The validator returns `(is_valid, reason)` so that rejected records can be diagnosed.

## 5. How to run
Open a terminal in this folder and run:

```bash
python main.py
```

On the first run, the program reads `contacts.csv`, validates each row and creates `students_clean.csv`. On later runs it loads the saved clean file so that changes made through the menu remain available.

## 6. Menu options
1. **View All Students** – displays student ID, name, phone and email.
2. **Search Record** – searches by exact name, phone or email.
3. **Register Student** – validates new details and checks duplicates.
4. **Update Student** – updates a record selected by ID or phone; Enter keeps an existing field.
5. **Delete Student** – deletes by ID or phone after confirmation.
6. **Analytics Report** – shows initial CSV data-quality results, rejection categories, phone-prefix distribution, email-domain counts and rejected-row diagnostics.
7. **Exit** – saves records to `students_clean.csv`.

## 7. Analytics definitions
- **Data quality accuracy / acceptance rate** = accepted input records ÷ total input records × 100.
- **Rejection categories** count missing names, invalid phones, bad emails and duplicates.
- **Telecom distribution** counts accepted phone numbers by first digit (9, 8, 7, 6).
- **Email domain distribution** counts accepted addresses by the text after `@`.

The report is calculated from the actual CSV records. The assignment PDF's preview states 13 accepted and 7 rejected, but its 20 sample rows, when its stated validation and duplicate rules are applied, result in 12 accepted and 8 rejected. The program reports the calculated result rather than forcing the preview figures.

## 8. Testing
Run the included test cases using:

```bash
python -m unittest discover -s proof -p "test_*.py" -v
```

See `proof/test_cases.txt` and `proof/console_output.txt` for test and sample-run evidence.

## 9. Concepts demonstrated
Variables, strings, lists, dictionaries, sets, functions, loops, conditional statements, CSV file handling, modular programming and dictionary-based frequency counting.

## 10. Viva preparation
- **Why store phone numbers as strings?** Phone numbers are identifiers, not quantities. Strings preserve leading zeroes and support `.isdigit()` and length checks.
- **Why use `csv.DictReader`?** It accesses values by column header names rather than fixed numeric indexes.
- **What does `.strip()` do?** Removes leading and trailing whitespace.
- **What does `.isdigit()` do?** Checks whether all characters are digits.
- **What does `.startswith()` do?** Checks the beginning of a string.
- **Why use sets for duplicates?** Set membership checks are efficient and prevent repeated phone/email values.
- **How are analytics counts calculated?** A dictionary stores a count for each key, incremented with `counts[key] = counts.get(key, 0) + 1`.
- **Why separate `validator.py`?** The same validation function can be reused by CSV ingestion and interactive registration/update operations.

## 11. Submission checklist
- [ ] Upload the complete folder to a **public Git repository**.
- [ ] Confirm all Python files and `contacts.csv` are included.
- [ ] Run the program and capture your own terminal screenshots.
- [ ] Keep the `proof/` folder in the repository.
- [ ] Read and understand the code so you can explain it during the viva.
- [ ] Copy the GitHub repository URL into your submission.

**Important:** Review and personalize the project, run it on your own computer, and be prepared to explain each function during your viva.
