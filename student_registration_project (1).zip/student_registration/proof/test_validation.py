import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from validator import validate_contact
from loader import load_contacts

class ValidationTests(unittest.TestCase):
    def test_valid_contact(self):
        self.assertTrue(validate_contact("Aarav Sharma", "9876543210", "a@gmail.com")[0])
    def test_blank_name(self):
        self.assertFalse(validate_contact("   ", "9876543210", "a@gmail.com")[0])
    def test_phone_must_be_10_digits(self):
        self.assertFalse(validate_contact("A", "98765", "a@gmail.com")[0])
    def test_phone_must_start_6789(self):
        self.assertFalse(validate_contact("A", "5123456789", "a@gmail.com")[0])
    def test_phone_must_be_digits(self):
        self.assertFalse(validate_contact("A", "98765abc10", "a@gmail.com")[0])
    def test_email_multiple_at(self):
        self.assertFalse(validate_contact("A", "9876543210", "a@@gmail.com")[0])
    def test_email_whitespace(self):
        self.assertFalse(validate_contact("A", "9876543210", "a b@gmail.com")[0])
    def test_email_domain_period(self):
        self.assertFalse(validate_contact("A", "9876543210", "a@gmailcom")[0])
    def test_sample_csv_counts(self):
        students, stats = load_contacts(Path(__file__).resolve().parents[1] / "contacts.csv")
        self.assertEqual(stats["total"], 20)
        self.assertEqual(stats["accepted"], 12)
        self.assertEqual(stats["rejected_count"], 8)
        self.assertEqual(len(students), 12)

if __name__ == "__main__":
    unittest.main()
