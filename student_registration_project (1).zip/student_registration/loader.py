"""CSV ingestion, duplicate detection, and clean-file persistence."""
import csv
from pathlib import Path
from validator import validate_contact

FIELDNAMES = ["name", "phone", "email"]

def load_contacts(filename="contacts.csv"):
    students, seen_phones, seen_emails = [], set(), set()
    rejected = []
    total = 0
    path = Path(filename)
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path.resolve()}")

    with path.open("r", newline="", encoding="utf-8-sig") as csvfile:
        reader = csv.DictReader(csvfile)
        for row_number, row in enumerate(reader, start=2):
            total += 1
            name = (row.get("name") or "").strip()
            phone = (row.get("phone") or "").strip()
            email = (row.get("email") or "").strip().lower()
            valid, reason = validate_contact(name, phone, email)
            if not valid:
                rejected.append({"row": row_number, "name": name, "reason": reason})
                continue
            if phone in seen_phones:
                rejected.append({"row": row_number, "name": name,
                                 "reason": f"Duplicate: phone {phone} is already registered."})
                continue
            if email in seen_emails:
                rejected.append({"row": row_number, "name": name,
                                 "reason": f"Duplicate: email {email} is already registered."})
                continue
            student = {"id": len(students) + 1, "name": name,
                       "phone": phone, "email": email}
            students.append(student)
            seen_phones.add(phone)
            seen_emails.add(email)

    stats = {"total": total, "accepted": len(students),
             "rejected": rejected, "rejected_count": len(rejected)}
    return students, stats

def save_students(students, filename="students_clean.csv"):
    with open(filename, "w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=["id"] + FIELDNAMES)
        writer.writeheader()
        for student in students:
            writer.writerow({key: student.get(key, "") for key in writer.fieldnames})

def load_students(filename="students_clean.csv"):
    path = Path(filename)
    if not path.exists():
        return []
    students = []
    with path.open("r", newline="", encoding="utf-8-sig") as csvfile:
        reader = csv.DictReader(csvfile)
        for index, row in enumerate(reader, start=1):
            students.append({"id": int(row.get("id") or index),
                             "name": (row.get("name") or "").strip(),
                             "phone": (row.get("phone") or "").strip(),
                             "email": (row.get("email") or "").strip().lower()})
    return students
