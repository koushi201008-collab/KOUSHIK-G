"""Interactive Student Registration & Contact Intelligence System."""
from pathlib import Path
from validator import validate_contact
from loader import load_contacts, load_students, save_students
from analytics import print_report

CLEAN_FILE = "students_clean.csv"
RAW_FILE = "contacts.csv"

def display_students(students):
    if not students:
        print("\\nNo student records found.")
        return
    print("\\n{:<5} {:<24} {:<12} {}".format("ID", "NAME", "PHONE", "EMAIL"))
    print("-" * 78)
    for s in students:
        print("{:<5} {:<24} {:<12} {}".format(
            s["id"], s["name"][:23], s["phone"], s["email"]))

def next_id(students):
    return max((s["id"] for s in students), default=0) + 1

def find_student(students, query):
    query = query.strip().lower()
    return [s for s in students if query in
            (s["name"].lower(), s["phone"].lower(), s["email"].lower())]

def unique_conflict(students, phone, email, exclude_id=None):
    for s in students:
        if s["id"] == exclude_id:
            continue
        if s["phone"] == phone:
            return "Phone number is already registered."
        if s["email"].lower() == email.lower():
            return "Email address is already registered."
    return ""

def register_student(students):
    print("\\n--- Register Student ---")
    name = input("Student name: ").strip()
    phone = input("Phone (10 digits): ").strip()
    email = input("Email: ").strip().lower()
    valid, reason = validate_contact(name, phone, email)
    if not valid:
        print("Registration failed:", reason)
        return
    conflict = unique_conflict(students, phone, email)
    if conflict:
        print("Registration failed:", conflict)
        return
    students.append({"id": next_id(students), "name": name,
                     "phone": phone, "email": email})
    save_students(students, CLEAN_FILE)
    print("Student registered successfully.")

def update_student(students):
    if not students:
        print("No records to update.")
        return
    query = input("Enter student ID or phone number: ").strip()
    match = next((s for s in students
                  if str(s["id"]) == query or s["phone"] == query), None)
    if not match:
        print("Student not found.")
        return
    print("Press Enter to keep the current value.")
    name = input(f"Name [{match['name']}]: ").strip() or match["name"]
    phone = input(f"Phone [{match['phone']}]: ").strip() or match["phone"]
    email = input(f"Email [{match['email']}]: ").strip().lower() or match["email"]
    valid, reason = validate_contact(name, phone, email)
    if not valid:
        print("Update failed:", reason)
        return
    conflict = unique_conflict(students, phone, email, match["id"])
    if conflict:
        print("Update failed:", conflict)
        return
    match.update({"name": name, "phone": phone, "email": email})
    save_students(students, CLEAN_FILE)
    print("Student updated successfully.")

def delete_student(students):
    query = input("Enter student ID or phone number to delete: ").strip()
    match = next((s for s in students
                  if str(s["id"]) == query or s["phone"] == query), None)
    if not match:
        print("Student not found.")
        return
    confirm = input(f"Delete {match['name']}? (y/n): ").strip().lower()
    if confirm == "y":
        students.remove(match)
        save_students(students, CLEAN_FILE)
        print("Student deleted.")
    else:
        print("Delete cancelled.")

def search_student(students):
    query = input("Enter exact name, phone number, or email: ").strip()
    results = find_student(students, query)
    display_students(results)

def print_menu():
    print("\\n========== STUDENT REGISTRATION SYSTEM ==========")
    print("1. View All Students")
    print("2. Search Record")
    print("3. Register Student")
    print("4. Update Student")
    print("5. Delete Student")
    print("6. Analytics Report")
    print("7. Exit")
    print("=================================================")

def main():
    try:
        _, ingestion_stats = load_contacts(RAW_FILE)
    except FileNotFoundError as error:
        print(error)
        return

    if Path(CLEAN_FILE).exists():
        students = load_students(CLEAN_FILE)
    else:
        students, _ = load_contacts(RAW_FILE)
        save_students(students, CLEAN_FILE)

    print("\\nWelcome to the Student Registration & Contact Intelligence System!")
    print(f"Initial CSV ingestion: {ingestion_stats['total']} rows, "
          f"{ingestion_stats['accepted']} accepted, "
          f"{ingestion_stats['rejected_count']} rejected.")
    while True:
        print_menu()
        choice = input("Choose an option (1-7): ").strip()
        if choice == "1":
            display_students(students)
        elif choice == "2":
            search_student(students)
        elif choice == "3":
            register_student(students)
        elif choice == "4":
            update_student(students)
        elif choice == "5":
            delete_student(students)
        elif choice == "6":
            print_report(students, ingestion_stats)
            print("\\nRejected row diagnostics:")
            for item in ingestion_stats["rejected"]:
                print(f"Row {item['row']}: {item['reason']}")
        elif choice == "7":
            save_students(students, CLEAN_FILE)
            print("Records saved. Thank you for using the system.")
            break
        else:
            print("Invalid choice. Please enter a number from 1 to 7.")

if __name__ == "__main__":
    main()
