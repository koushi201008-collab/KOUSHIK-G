"""Business intelligence summaries using basic Python collections."""

def build_analytics(students, ingestion_stats):
    total = ingestion_stats["total"]
    accepted = ingestion_stats["accepted"]
    rejected = ingestion_stats["rejected"]
    accuracy = (accepted / total * 100) if total else 0.0

    error_counts = {}
    for item in rejected:
        reason = item["reason"]
        if reason.startswith("Invalid Phone"):
            category = "Invalid Phone"
        elif reason.startswith("Bad Email"):
            category = "Bad Email"
        elif reason.startswith("Missing Name"):
            category = "Missing Name"
        elif reason.startswith("Duplicate"):
            category = "Duplicate"
        else:
            category = "Other"
        error_counts[category] = error_counts.get(category, 0) + 1

    prefix_counts = {digit: 0 for digit in "9876"}
    domain_counts = {}
    for student in students:
        prefix = student["phone"][0]
        if prefix in prefix_counts:
            prefix_counts[prefix] += 1
        domain = student["email"].split("@")[-1]
        domain_counts[domain] = domain_counts.get(domain, 0) + 1

    return {"total": total, "accepted": accepted,
            "rejected_count": len(rejected), "accuracy": accuracy,
            "error_counts": error_counts, "prefix_counts": prefix_counts,
            "domain_counts": dict(sorted(domain_counts.items(),
                                         key=lambda item: (-item[1], item[0])))}

def print_report(students, ingestion_stats):
    report = build_analytics(students, ingestion_stats)
    line = "=" * 62
    print("\\n" + line)
    print("          STUDENT REGISTRATION - BUSINESS INTELLIGENCE")
    print(line)
    print(f"Total Contacts Processed : {report['total']}")
    print(f"Valid Registrations      : {report['accepted']}")
    print(f"Rejected Records         : {report['rejected_count']}")
    print(f"Data Quality Accuracy   : {report['accuracy']:.1f}%")
    print("\\n--- Rejection Reason Breakdown ---")
    if report["error_counts"]:
        for reason, count in report["error_counts"].items():
            print(f"{reason:<24}: {count}")
    else:
        print("No rejected records.")
    print("\\n--- Telecom Network Breakdown ---")
    for digit in "9876":
        print(f"{digit}-Series{'':<18}: {report['prefix_counts'][digit]} students")
    print("\\n--- Top Email Domains ---")
    for domain, count in report["domain_counts"].items():
        print(f"@{domain:<22}: {count} students")
    print(line)
