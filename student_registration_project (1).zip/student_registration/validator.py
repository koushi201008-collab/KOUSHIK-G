"""Field validation for student contact records."""

def validate_contact(name, phone, email):
    name = (name or "").strip()
    phone = (phone or "").strip()
    email = (email or "").strip()

    if not name:
        return False, "Missing Name: student name is blank."
    if not phone:
        return False, "Invalid Phone: phone number is missing/empty."
    if len(phone) != 10 or not phone.isdigit() or phone[0] not in "6789":
        return False, "Invalid Phone: must be 10 digits and start with 6, 7, 8, or 9."
    if email.count("@") != 1:
        return False, "Bad Email: must contain exactly one @ symbol."
    if any(ch.isspace() for ch in email):
        return False, "Bad Email: whitespace is not allowed."
    local, domain = email.split("@")
    if not local:
        return False, "Bad Email: characters are required before @."
    if "." not in domain or domain.startswith(".") or domain.endswith("."):
        return False, "Bad Email: domain must contain a period that is not first or last."
    return True, "Valid contact."
